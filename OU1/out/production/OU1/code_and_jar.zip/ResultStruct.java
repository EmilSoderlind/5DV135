/**
 * Struct to store test-results from unittest methods invocations
 */

public class ResultStruct {
    public boolean success = false;
    public boolean exception = false;
    public String exceptionName = "empty";
}
