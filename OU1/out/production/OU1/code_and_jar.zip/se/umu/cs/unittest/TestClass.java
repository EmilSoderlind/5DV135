package se.umu.cs.unittest;

public interface TestClass {
}